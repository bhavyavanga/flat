package com.cg.flat.presentation;

import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.flat.bean.FlatRegistrationDTO;
import com.cg.flat.bean.OwnersDetails;
import com.cg.flat.exceptions.FlatExceptions;
import com.cg.flat.service.FlatRegistrationServiceImpl;

public class MainClient {

	static FlatRegistrationServiceImpl  service=new FlatRegistrationServiceImpl();
	static Scanner scanner=new Scanner(System.in);
	static void registerDetails()
	{
           int ownerId=0;	
			List<Integer> list1=service.getAllOwnerIds();
			List<OwnersDetails> list2=service.getAllOwner();
		System.out.println("existing owner id=" +list1);
		boolean OwnerFlag=false;
		do {
		System.out.println("please enter your owner id from above list:");
		
		 ownerId=scanner.nextInt();
		 
	          OwnerFlag=true;
            if(!list1.contains(ownerId))
         {
        	try {
			throw new FlatExceptions("please enter from the list printed above");
			} catch (FlatExceptions e) {
			
			OwnerFlag=false;
				System.err.println(e.getMessage());
				
				}	            }
		}while(!OwnerFlag);
		String name=null;
		long number=0;
		Iterator<OwnersDetails> iterator=list2.iterator();
		while(iterator.hasNext())
		{
			OwnersDetails ownersDetails=iterator.next();
			if(ownerId==ownersDetails.getOwnerId())
			{
				name=ownersDetails.getName();
				number=ownersDetails.getPhoneNumber();
			}
			
		}
		boolean flatTypeFlag=false;
		int flatType=0;
		do {
		System.out.println("select flattype (1-1BHK , 2-2BHK):");
		 flatType=scanner.nextInt();
		flatTypeFlag=true;
	
		if((flatType!=1)&&flatType!=2)
		{
			try {
				throw new FlatExceptions("enter correct option");
			}catch (FlatExceptions e) {
				flatTypeFlag=false;
			System.err.println(e.getMessage());
			}
		}
			
		}while(!flatTypeFlag);
		
		
		System.out.println("enter flat area in sq.ft.:");
		int flatArea=scanner.nextInt();
		System.out.println("enter desired rent:");
		int rent=scanner.nextInt();
       // System.out.println("enter desired deposit");
        int deposit=0;
        boolean flag=false;
        do {
        	System.out.println("enter desired deposit");
        deposit=scanner.nextInt();
        flag=true;
        if(deposit<rent)
        {
        	try {
        		throw new FlatExceptions("deposit can't be less than rent");
        	}catch (FlatExceptions e) {
        		flag=false;
				System.err.println(e.getMessage());
			}
        }
        
        }while(!flag);
       
       
        
        	
        
       OwnersDetails owners=new OwnersDetails(ownerId, name,number);
        FlatRegistrationDTO flat=new FlatRegistrationDTO(flatType, flatArea, rent, deposit,owners, 0);
        FlatRegistrationDTO registrationId=service.registerFlat(flat);
        System.out.println("Flat successfully registered. Registration Id="+flat.getRegistrationId());
	
	}
	
	

public static void main(String[] args) {
	boolean choiceFlag = false;
	String continueChoice;
	boolean continueValue = false;

	do {
		try {
			System.out.println("1.regsiter \n2.ViewAll\n 3.Exit");
			int choice = scanner.nextInt();
			switch (choice) {
			
			case 1:
				registerDetails();
				break;
			case 2:
			System.out.println(service.getAllFlatDetails());
				break;
			case 3:System.out.println("thank you");
			System.exit(0);
			default:
				System.out.println("choice shld be 1,2 or 3");
				break;
			}

		} catch (InputMismatchException e) {
			choiceFlag = false;
			System.err.println("input should contains digits");
		}
		do {
			scanner = new Scanner(System.in);
			System.out.println("do you want to continue again [yes/no]");
			continueChoice = scanner.nextLine();
			if (continueChoice.equalsIgnoreCase("yes")) {
				continueValue = true;
				break;
			} else if (continueChoice.equalsIgnoreCase("no")) {
				System.out.println("thank you");
				continueValue = false;
				break;
			} else {
				System.out.println("enter yes or no");
				continueValue = false;
				continue;
			}
		} while (!continueValue);

	} while (continueValue);

	scanner.close();
	
}
}
