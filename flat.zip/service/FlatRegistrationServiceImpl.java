package com.cg.flat.service;

import java.util.ArrayList;

import com.cg.flat.bean.FlatRegistrationDTO;
import com.cg.flat.bean.OwnersDetails;
import com.cg.flat.dao.FlatRegistrationDAOImpl;
import com.cg.flat.dao.IFlatRegistrationDAO;

public class FlatRegistrationServiceImpl implements IFlatRegistrationService {

	IFlatRegistrationDAO dao=new FlatRegistrationDAOImpl();
	@Override
	public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat) {
		int id=(int)(Math.random()*1000);
		flat.setRegistrationId(id);
		return dao.registerFlat(flat);
	}

	@Override
	public ArrayList<Integer> getAllOwnerIds() {
		
		return dao.getAllOwnerIds();
	}
	//public int RegistrationId() {
		//int id=(int)(Math.random()*1000);
		//return id;
//}
	public ArrayList<FlatRegistrationDTO> getAllFlatDetails(){
		return dao.getFlatDetails();
		 
			
		
	}
	public ArrayList<OwnersDetails> getAllOwner(){
		return dao.getOwner();
		
	}
}
