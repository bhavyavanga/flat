package com.cg.flat.service;

import java.util.ArrayList;

import com.cg.flat.bean.FlatRegistrationDTO;
import com.cg.flat.bean.OwnersDetails;

public interface IFlatRegistrationService {

	FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat);
	ArrayList<Integer> getAllOwnerIds();
	ArrayList<OwnersDetails> getAllOwner();
	
}
