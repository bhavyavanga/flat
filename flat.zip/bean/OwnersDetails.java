package com.cg.flat.bean;

public class OwnersDetails {

	
		private int ownerId;
		private String name;
		private long phoneNumber;
		public OwnersDetails() {
			super();
			// TODO Auto-generated constructor stub
		}
		public OwnersDetails(int ownerId, String name, long phoneNumber) {
			super();
			this.ownerId = ownerId;
			this.name = name;
			this.phoneNumber = phoneNumber;
		}
		public int getOwnerId() {
			return ownerId;
		}
		public void setOwnerId(int ownerId) {
			this.ownerId = ownerId;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public long getPhoneNumber() {
			return phoneNumber;
		}
		public void setPhoneNumber(long phoneNumber) {
			this.phoneNumber = phoneNumber;
		}
		@Override
		public String toString() {
			return "OwnersDetails [ownerId=" + ownerId + ", name=" + name + ", phoneNumber=" + phoneNumber + "]";
		}
	
}
