package com.cg.flat.bean;

public class FlatRegistrationDTO {

	private int flatType;
	private int area;
	private int rent;
	private int deposit;
	private OwnersDetails owners;
	private int registrationId;
	public FlatRegistrationDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public FlatRegistrationDTO(int flatType, int area, int rent, int deposit, OwnersDetails owners, int registrationId) {
		super();
		this.flatType = flatType;
		this.area = area;
		this.rent = rent;
		this.deposit = deposit;
		this.owners = owners;
		this.registrationId = registrationId;
	}
	public int getFlatType() {
		return flatType;
	}
	public void setFlatType(int flatType) {
		this.flatType = flatType;
	}
	public int getArea() {
		return area;
	}
	public void setArea(int area) {
		this.area = area;
	}
	public int getRent() {
		return rent;
	}
	public void setRent(int rent) {
		this.rent = rent;
	}
	public int getDeposit() {
		return deposit;
	}
	public void setDeposit(int deposit) {
		this.deposit = deposit;
	}
	public OwnersDetails getOwners() {
		return owners;
	}
	public void setOwners(OwnersDetails owners) {
		this.owners = owners;
	}
	public int getRegistrationId() {
		return registrationId;
	}
	public void setRegistrationId(int registrationId) {
		this.registrationId = registrationId;
	}
	@Override
	public String toString() {
		return "FlatRegistrationDTO [flatType=" + flatType + ", area=" + area + ", rent=" + rent + ", deposit=" + deposit
				+ ", owners=" + owners + ", registrationId=" + registrationId + "]";
	}
	
}
