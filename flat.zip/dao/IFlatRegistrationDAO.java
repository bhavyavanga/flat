package com.cg.flat.dao;

import java.util.ArrayList;

import com.cg.flat.bean.FlatRegistrationDTO;
import com.cg.flat.bean.OwnersDetails;

public interface IFlatRegistrationDAO {

	FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat);
	ArrayList<Integer> getAllOwnerIds();
	public ArrayList<FlatRegistrationDTO> getFlatDetails();
	ArrayList<OwnersDetails> getOwner();
	
}
