package com.cg.flat.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.cg.flat.bean.FlatRegistrationDTO;
import com.cg.flat.bean.OwnersDetails;

public class FlatRegistrationDAOImpl implements IFlatRegistrationDAO {

	 Map<Integer, OwnersDetails> owners=new HashMap<Integer, OwnersDetails>();
	 public  Map<Integer, OwnersDetails> getOwnerDetails(){
		owners.put(1,new OwnersDetails(1,"Vaishali",9023002122L));
		owners.put(2,new OwnersDetails(2,"Megha",9643221234L));
		owners.put(3,new OwnersDetails(3,"Manish",5453221234L));
		
		return owners;
	}
	Map<Integer,FlatRegistrationDTO > flatDetails=new HashMap<>();


		public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat) {
			
			flatDetails.put(flat.getRegistrationId(), flat);
			
			return flat;
		}

		public ArrayList<Integer> getAllOwnerIds() {
			ArrayList<Integer> ownerIds=new ArrayList<>(getOwnerDetails().keySet());
			
			return ownerIds;
		}
		public ArrayList<FlatRegistrationDTO> getFlatDetails(){
			
			ArrayList<FlatRegistrationDTO> flatdetails1=new ArrayList<>();
			Collection<FlatRegistrationDTO> collection=flatDetails.values();
			flatdetails1.addAll(collection);
			return flatdetails1;
			
		
			
			
		}
		public ArrayList<OwnersDetails> getOwner(){

			ArrayList<OwnersDetails> details1=new ArrayList<>();
			Collection<OwnersDetails> collection= getOwnerDetails().values();
			details1.addAll(collection);
			return details1;
			
			
		}
		
}
